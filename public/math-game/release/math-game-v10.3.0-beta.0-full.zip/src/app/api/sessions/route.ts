// POST /api/sessions — ثبت جلسهٔ تمرین از بازی (پل بازی ↔ داشبورد)
// بدنه: { studentId? | studentName?, layer, results: [{a,b,correct,timeSec?}], ... }

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { layerName } from '@/lib/dashboard/constants';
import { nextChainFields, integrityOfResults } from '@/lib/dashboard/chain-server';
import type { PostSessionResponse } from '@/lib/dashboard/types';

export const dynamic = 'force-dynamic';

const bodySchema = z.object({
  eventId: z.string().min(6).max(120).optional(),
  studentId: z.string().min(1).max(64).optional(),
  studentName: z.string().min(2).max(60).optional(),
  grade: z.number().int().min(1).max(6).optional(),
  hero: z.enum(['astronaut', 'pilot', 'scientist']).optional(),
  buildingId: z
    .union([z.string().min(1).max(60), z.number().int().min(0).max(99)])
    .transform((v) => String(v))
    .optional(),
  layer: z.number().int().min(1).max(9),
  mode: z.enum(['station', 'online', 'side']).default('station'),
  missionId: z.string().min(3).max(60).optional(), // مأموریت جانبی (برای تکمیل خودکار مأموریت معلم)
  durationSec: z.number().min(0).max(7200).optional(),
  results: z
    .array(
      z.object({
        a: z.number().int().min(0).max(20),
        b: z.number().int().min(0).max(20),
        correct: z.boolean(),
        timeSec: z.number().min(0).max(300).optional(),
        submitted: z.number().int().min(0).max(400).nullable().optional(), // پاسخ واقعی دانش‌آموز (شاهد تشخیص)
      })
    )
    .min(1)
    .max(60),
  hintsMax: z.number().int().min(0).max(7).optional(), // بیشترین پلهٔ راهنما — تشخیص تکدی سرنخ
});

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'بدنهٔ JSON نامعتبر است' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    console.error('[sessions] invalid payload:', JSON.stringify(body).slice(0, 600), '→', JSON.stringify(parsed.error.flatten().fieldErrors));
    return NextResponse.json(
      { ok: false, error: 'اعتبارسنجی ناموفق', details: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }
  const data = parsed.data;

  /** حلقهٔ کامل: اتمام مأموریت جانبی در بازی = تکمیل خودکار مأموریت معلم */
  async function completeSideAssignments(studentId: string, missionId: string, sessionId: string) {
    try {
      const r = await db.assignment.updateMany({
        where: { studentId, missionId, status: { in: ['pending', 'seen'] } },
        data: { status: 'completed', completedAt: new Date(), sessionId },
      });
      if (r.count > 0) console.log('[assignments] auto-completed:', r.count, missionId);
    } catch (e) {
      console.error('[assignments] auto-complete failed:', e instanceof Error ? e.message : e);
    }
  }

  // ─── Idempotency: رویداد تکراری (ریترای شبکه) رکورد جدید نمی‌سازد ───
  if (data.eventId) {
    const existing = await db.session.findUnique({
      where: { eventId: data.eventId },
      include: { student: true },
    });
    if (existing) {
      const res: PostSessionResponse = {
        ok: true,
        duplicate: true,
        sessionId: existing.id,
        studentId: existing.studentId,
        studentName: existing.student.name,
        total: existing.total,
        correct: existing.correct,
        accuracy: existing.total > 0 ? existing.correct / existing.total : 0,
        layerName: layerName(existing.layer),
      };
      if (data.mode === 'side' && data.missionId) {
        await completeSideAssignments(existing.studentId, data.missionId, existing.id);
      }
      return NextResponse.json(res, { status: 200 });
    }
  }

  // یافتن یا ساخت دانش‌آموز
  let student = data.studentId ? await db.student.findUnique({ where: { id: data.studentId } }) : null;
  if (!student && data.studentName) {
    student = await db.student.findFirst({ where: { name: data.studentName } });
  }
  if (!student) {
    if (!data.studentName) {
      return NextResponse.json({ ok: false, error: 'studentId یا studentName لازم است' }, { status: 400 });
    }
    student = await db.student.create({
      data: { name: data.studentName, grade: data.grade ?? 4, hero: data.hero ?? 'astronaut' },
    });
  }

  const total = data.results.length;
  const correct = data.results.filter((r) => r.correct).length;

  // ─── فروشگاه رویداد فقط‌الحاقی (CEAP §4): ساعت لامپورت + زنجیرهٔ رسید + integrity ───
  const chainEvent = {
    eventId: data.eventId ?? null,
    studentId: student.id,
    buildingId: data.buildingId ?? 'unknown',
    layer: data.layer,
    mode: data.mode,
    total,
    correct,
    results: data.results.map((r) => ({
      a: r.a,
      b: r.b,
      correct: r.correct,
      submitted: r.submitted ?? null,
      timeSec: r.timeSec ?? 0,
    })),
  };
  const chain = await nextChainFields(student.id, chainEvent);
  const integrity = integrityOfResults(data.results);
  if (!integrity) console.warn('[sessions] integrity mismatch (submitted ↔ correct) — flagged:', data.eventId);

  let session;
  try {
    session = await db.session.create({
      data: {
        studentId: student.id,
        buildingId: data.buildingId ?? 'unknown',
        layer: data.layer,
        mode: data.mode,
        total,
        correct,
        durationSec: Math.round(data.durationSec ?? 0),
        eventId: data.eventId,
        lamportClock: chain.lamportClock,
        prevReceipt: chain.prevReceipt,
        receipt: chain.receipt,
        integrity,
        results: {
          create: data.results.map((r) => ({
            studentId: student.id,
            a: r.a,
            b: r.b,
            correct: r.correct,
            submitted: r.submitted ?? null,
            timeSec: r.timeSec ?? 0,
            layer: data.layer,
          })),
        },
      },
    });
  } catch (err) {
    // مسابقهٔ همزمان: دو درخواست با همان eventId — اولی برنده است
    if (
      data.eventId &&
      typeof err === 'object' &&
      err !== null &&
      'code' in err &&
      (err as { code?: string }).code === 'P2002'
    ) {
      const existing = await db.session.findUnique({
        where: { eventId: data.eventId },
        include: { student: true },
      });
      if (existing) {
        const res: PostSessionResponse = {
          ok: true,
          duplicate: true,
          sessionId: existing.id,
          studentId: existing.studentId,
          studentName: existing.student.name,
          total: existing.total,
          correct: existing.correct,
          accuracy: existing.total > 0 ? existing.correct / existing.total : 0,
          layerName: layerName(existing.layer),
        };
        return NextResponse.json(res, { status: 200 });
      }
    }
    throw err;
  }

  if (data.mode === 'side' && data.missionId) {
    await completeSideAssignments(student.id, data.missionId, session.id);
  }

  const res: PostSessionResponse = {
    ok: true,
    sessionId: session.id,
    studentId: student.id,
    studentName: student.name,
    total,
    correct,
    accuracy: total > 0 ? correct / total : 0,
    layerName: layerName(data.layer),
  };
  return NextResponse.json(res, { status: 201 });
}
